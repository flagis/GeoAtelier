#pragma once

char ssid[] = "FLAGIS";     // ssid
char pass[] = "flagis2022"; // wifi password
